# Sandbloxa-AiFF

Sandbloxa website:
https://sites.google.com/my.prideschools.org/offical-sandbloxa/home
(You can no longer download things from the site, the launch page will be updated though

There are 3 versions of sandbloxa
 - Sandbloxa,
 - Sandbloxa NIGHT,
 - Sandbloxa EN/SPANISH,
 
 ----------------------
 - Stop updating Sandbloxa
 - Done
 - Realease Sandbloxa NIGHT
 - 
 - Keep updating Sandbloxa EN/SPANISH
 - Done
 
Download here:
https://github.com/PJSRE/Sandbloxa-AiFF/archive/refs/heads/main.zip
